package com.zhaolong.util;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.zhaolong.bean.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
public class TokenGeneratorUtil {
	public static String getTokenUerid(String token) {
		//String token = request.getHeader("token");// 从 http 请求头中取出 token
		System.out.println("token--->"+token);
		String userId = JWT.decode(token).getAudience().get(0);//从token中获取登录的id
		return userId;
	}

	public static String getTokenGenerator(Users us){
		String token=null;

		Date start=new Date();
		//获取系统指定的当前时间,设置token超时时间为1小时
		Long cdate=System.currentTimeMillis()+60*60*1000;

		Date end = new Date(cdate);

		//生成token字符串
		token= JWT.create().withAudience(us.getUid().toString()).withIssuedAt(start).withExpiresAt(end).sign(Algorithm.HMAC256(us.getPasswd()));
		System.out.println("token--->"+token);
		return token;
	}
}
