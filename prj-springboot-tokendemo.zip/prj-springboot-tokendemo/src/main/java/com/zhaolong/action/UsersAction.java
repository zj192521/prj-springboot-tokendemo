package com.zhaolong.action;
import java.util.*;
import com.zhaolong.bean.*;
import com.zhaolong.util.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.Jedis;

import javax.servlet.http.HttpServletRequest;

@RestController
public class UsersAction {
	@RequestMapping(value = "check_Users.do")
	public String check(HttpServletRequest request,Users us){
		us=us==null?new Users(1, "张飞", "1234356"):us;
		us.setUid(41);//设置id值，主要是客户端值传递账号和密码，无编号，此处模拟从数据库取出的编号
		String tokenstr=request.getHeader("token");
		System.out.println("us--->"+us.getUname());
		try {
			//调用工具类获取Token字符串，将此token字符串发送到客户端保存
			String tk=TokenGeneratorUtil.getTokenGenerator(us);
			System.out.println("action-->token-->"+tk);
			Jedis jedis=new Jedis("localhost",6379);	//替换为实际连接地址与端口
			jedis.set("mytoken",tk);
			return "ok";
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "fail";
	}
	@RequestMapping(value = "findByTokenUid_Users.do")
	public String findByTokenUid(){
		Jedis jedis=new Jedis("localhost",6379);	//替换为实际连接地址与端口
		//从redis中获取token字符串
		String tokenstr=jedis.get("mytoken");
		System.out.println("tokenstr-->"+tokenstr);
		//使用工具类获取用户的id
		String uid=TokenGeneratorUtil.getTokenUerid(tokenstr);
		return uid;
	}
}
